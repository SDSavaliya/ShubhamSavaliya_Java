package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bin.Doctorsbean;
import com.bin.Registrationbean;
import com.model.Doctorsmodel;
import com.model.Registrationmodel;

@WebServlet("/DoctorLogin")
public class DoctorLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DoctorLogin() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		System.out.println("Checking Doctor Login Servlet...");

		Doctorsbean d = new Doctorsbean();
		String email = request.getParameter("docemail");
		String password = request.getParameter("password");

		d.setEmail(email);
		d.setPass(password);

		Doctorsmodel dm = new Doctorsmodel();
		Doctorsbean flag = dm.checklogin(d);
		if (flag != null) {
			System.out.println("Doctor logged in successfully...");
			HttpSession session = request.getSession(true);
			session.setAttribute("dm", flag);
			Cookie ck = new Cookie("dm", email);
			ck.setMaxAge(60 * 60);
			response.addCookie(ck);
			response.sendRedirect("doctor/doctorhome.jsp");
		} else {
			System.out.println("Invalid doctor credentials...");
			request.getSession().setAttribute("msg", "Email or Password is Wrong");
			response.sendRedirect("doctor/doctorlogin.jsp");
		}
	}

}
