package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bin.Appointmentbean;
import com.bin.Doctorsbean;
import com.model.AppointmentModel;
import com.model.Doctorsmodel;

@WebServlet("/showDoctorAppointments")
public class showDoctorAppointments extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public showDoctorAppointments() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String drName = request.getParameter("DrName");
		Doctorsbean db = new Doctorsbean();
		db.setName(drName);

		AppointmentModel dm = new AppointmentModel();
		ArrayList<Appointmentbean> flag = dm.showappointmentbydoctor(db);
		if (flag != null) {
			System.out.println("Doctor logged in successfully...");
			HttpSession session = request.getSession(true);
			session.setAttribute("ab", flag);
			response.sendRedirect("doctor/showdoctorsappointments.jsp");
		} else {
			System.out.println("Invalid doctor credentials...");
			request.getSession().setAttribute("msg", "Email or Password is Wrong");
			response.sendRedirect("doctor/doctorhome.jsp");
		}

	}

}
