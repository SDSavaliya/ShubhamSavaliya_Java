package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bin.Appointmentbean;
import com.model.AppointmentModel;

@WebServlet("/changeAppointmentStatus")
public class changeAppointmentStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public changeAppointmentStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		AppointmentModel m = new AppointmentModel();
		int aid = Integer.parseInt(request.getParameter("aid"));
		Appointmentbean s = m.showappointmentbyid(aid);
		System.out.println(s.getId());

		String drname = request.getParameter("DrName");
		String status = request.getParameter("status");

		s.setStatus(status);
		s.setId(aid);
		System.out.println(aid);
		System.out.println(status);

		AppointmentModel am = new AppointmentModel();
		String updatestatus = am.updateStatus(s);
		if (updatestatus.equals("SUCCESS STATUS UPDATED")) {
			response.sendRedirect("doctor/showdoctorsappointments.jsp?DrName=" + drname);
		} else {
			response.sendRedirect("doctor/showdoctorsappointments.jsp?DrName=" + drname);
		}

		response.getWriter().append("status: " + status).append(request.getContextPath());
	}

}
