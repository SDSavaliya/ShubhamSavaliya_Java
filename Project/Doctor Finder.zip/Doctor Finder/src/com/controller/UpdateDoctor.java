package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bin.Doctorsbean;
import com.model.Doctorsmodel;

@WebServlet("/UpdateDoctor")
public class UpdateDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdateDoctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		int did = Integer.parseInt(request.getParameter("did"));
		String name = request.getParameter("name");
		String speciality = request.getParameter("speciality");
		String degree = request.getParameter("degree");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String contactno = request.getParameter("contact");
		String location = request.getParameter("location");

		response.getWriter().append("name at: " + name).append(request.getContextPath());
		response.getWriter().append("speciality at: " + speciality).append(request.getContextPath());

		Doctorsbean db = new Doctorsbean();
		db.setId(did);
		db.setName(name);
		db.setSpeciality(speciality);
		db.setDegree(degree);
		db.setState(state);
		db.setCity(city);
		db.setAddress(address);
		db.setEmail(email);
		db.setPass(password);
		db.setContact_no(contactno);
		db.setLocation(location);

		Doctorsmodel dm = new Doctorsmodel();
		String updateStatus = dm.updateDoctor(db);

		if (updateStatus.equals("Successfully Updated Doctor!")) {
			response.sendRedirect("doctor/updatedoctor.jsp");
			request.getSession().setAttribute("updatestatus", "Updated Details!");
		} else {
			request.getSession().setAttribute("updatestatus", "Couldn't update details, some error occured!");
			response.sendRedirect("doctor/updatedoctor.jsp");
		}
	}

}
