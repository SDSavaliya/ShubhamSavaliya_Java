package com.model;

import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.DBconnection.DBconnection;
import com.bin.Appointmentbean;
import com.bin.Doctorsbean;
import com.bin.Feedbackbean;
import com.bin.Registrationbean;

public class AppointmentModel {

	public void addappointment(Appointmentbean s) {
		try {
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql1 = "SET FOREIGN_KEY_CHECKS = 0;";
			PreparedStatement pst1 = conn.prepareStatement(sql1);
			pst1.executeUpdate();
			String sql = "insert into appointment(DrName,DrSpeciality,AppointmentDate,AppointmentTime,u_id,status) values(?,?,?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, s.getDrName());
			pst.setString(2, s.getDrSpeciality());
			pst.setString(3, s.getAppointmentDate());
			pst.setString(4, s.getAppointmentTime());
			pst.setInt(5, s.getId());
			pst.setString(6, "pending");
			int i = pst.executeUpdate();
			if (i > 0) {
				EmailSender gs = new EmailSender();
				String subject = "Appointment Created!";
				String msg = "New Doctor Appointment:\n\n" + "Doctor: " + s.getDrName() + "\n" 
				+ "Appointment Date: " + s.getAppointmentDate() + "\n"
						+ "Patient Name: "+s.getFname() +"\n"
						+ "Appointment Time: " + s.getAppointmentTime() + "\n" + "Appointment Status: Pending";

				Doctorsmodel dm=new Doctorsmodel();
				Registrationmodel rm=new Registrationmodel();
				String senderemail=dm.getdoctorEmail();
				String receieveremail=rm.getuserEmail(s.getUid());
				System.out.println("receieveremail"+senderemail);
				System.out.println("receieveremail: "+receieveremail);
				String emailstatus = gs.sendEmail(subject, msg,senderemail, receieveremail );
				if(emailstatus.equals("Sent message successfully")) {
					System.out.println("Sent email successfully");
				}else {
					System.out.println("Failed sending mail...");
				}
				System.out.println("success");
			} else {
				System.out.println("fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public Appointmentbean cancelappointment() {
		Appointmentbean s = null;
		try {
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql = "select * from appointment";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				
				s = new Appointmentbean();
				s.setId(Integer.parseInt(rs.getString("id")));
				s.setDrName(rs.getString("drname"));
				s.setDrSpeciality(rs.getString("DrSpeciality"));
				s.setAppointmentDate(rs.getString("AppointmentDate"));
				s.setAppointmentTime(rs.getString("AppointmentTime"));
				
				
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	public int deleteappointment(Appointmentbean s) {
		int i = 0;
		try {
			DBconnection db = new DBconnection();
			Connection conn = db.getconnection();
			String sql = "delete from appointment where id=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, s.getId());
			i = pst.executeUpdate();
			
			EmailSender gs = new EmailSender();
			String subject = "Appointment Cancelled!";
			String msg = "Doctor: " + s.getDrName() + "\n" 
			+ "Appointment Date: " + s.getAppointmentDate() + "\n"
					+ "Patient Name: "+s.getFname() +"\n"
					+ "Appointment Time: " + s.getAppointmentTime() + "\n" + "Appointment Status: Cancelled";

			Doctorsmodel dm=new Doctorsmodel();
			Registrationmodel rm=new Registrationmodel();
			String senderemail=dm.getdoctorEmail();
			String receieveremail=rm.getuserEmail(s.getUid());
			String emailstatus = gs.sendEmail(subject, msg,senderemail, receieveremail );
			if(emailstatus.equals("Sent message successfully")) {
				System.out.println("Sent email successfully");
			}else {
				System.out.println("Failed sending mail...");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public String updateStatus(Appointmentbean ab) {

		try {

			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

//			String sql = "select * from appointment where DrName='"+dr.getName()+"'";
//			
//			PreparedStatement pst = cnn.prepareStatement(sql);
//			
//			ResultSet rs = pst.executeQuery();

			PreparedStatement pstmt;
			PreparedStatement pstmt1;
			pstmt1 = cnn.prepareStatement("SET FOREIGN_KEY_CHECKS=0");
			pstmt1.executeUpdate();
			// updating item details query
			pstmt = cnn.prepareStatement("update appointment set status=? where id=?");
			pstmt.setString(1, ab.getStatus());
			pstmt.setInt(2, ab.getId());
			pstmt.executeUpdate();
			pstmt.close();
			cnn.close();
			
			
			EmailSender gs = new EmailSender();
			String subject = "Appointment Status Updated!";
			String msg = "Doctor: " + ab.getDrName() + "\n" 
			+ "Appointment Date: " + ab.getAppointmentDate() + "\n"
					+ "Patient Name: "+ab.getFname() +"\n"
					+ "Appointment Time: " + ab.getAppointmentTime() + "\n" + "Appointment Status: "+ab.getStatus();
			Doctorsmodel dm=new Doctorsmodel();
			Registrationmodel rm=new Registrationmodel();
			String senderemail=dm.getdoctorEmail();
			String receieveremail=rm.getuserEmail(ab.getUid());
			String emailstatus = gs.sendEmail(subject, msg,senderemail, receieveremail );
			if(emailstatus.equals("Sent message successfully")) {
				System.out.println("Sent email successfully");
			}else {
				System.out.println("Failed sending mail...");
			}
			return "SUCCESS STATUS UPDATED";
		} catch (Exception ex) {
			Logger.getLogger(AppointmentModel.class.getName()).log(Level.SEVERE, null, ex);
		}
		return "FAILED UPDATING STATUS";
	}

	public ArrayList<Appointmentbean> showappointmentbyuser(Registrationbean rb) {
		ArrayList<Appointmentbean> app = new ArrayList<Appointmentbean>();

		try {
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

			String sql = "select * from appointment where u_id='" + rb.getId() + "'";

			PreparedStatement pst = cnn.prepareStatement(sql);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				Appointmentbean app1 = new Appointmentbean();
				app1.setId(rs.getInt("id"));
				app1.setDrName(rs.getString("DrName"));
				app1.setDrSpeciality(rs.getString("DrSpeciality"));
				app1.setAppointmentDate(rs.getString("AppointmentDate"));
				app1.setAppointmentTime(rs.getString("AppointmentTime"));
				app1.setStatus(rs.getString("status"));
				app.add(app1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return app;
	}

	public ArrayList<Appointmentbean> showappointmentbydoctor(Doctorsbean dr) {
		ArrayList<Appointmentbean> app = new ArrayList<Appointmentbean>();

		try {
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

			String sql = "select * from user_regi INNER JOIN appointment on appointment.u_id=user_regi.u_id"
					+ " where appointment.DrName='" + dr.getName() + "'";

			PreparedStatement pst = cnn.prepareStatement(sql);

			ResultSet rs = pst.executeQuery();
//			Appointmentbean app1 = new Appointmentbean();
			while (rs.next()) {
				Appointmentbean app1 = new Appointmentbean();
				app1.setId(rs.getInt("id"));
				app1.setDrName(rs.getString("DrName"));
				app1.setDrSpeciality(rs.getString("DrSpeciality"));
				app1.setAppointmentDate(rs.getString("AppointmentDate"));
				app1.setAppointmentTime(rs.getString("AppointmentTime"));
				app1.setStatus(rs.getString("status"));
				app1.setFname(rs.getString("u_fname"));
				app1.setLname(rs.getString("u_lname"));
				app.add(app1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return app;
	}

	public ArrayList<Appointmentbean> showappointment() {
		ArrayList<Appointmentbean> app = new ArrayList<Appointmentbean>();

		try {
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

			String sql = "select * from appointment";

			PreparedStatement pst = cnn.prepareStatement(sql);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				Appointmentbean app1 = new Appointmentbean();
				app1.setId(rs.getInt("id"));
				app1.setDrName(rs.getString("DrName"));
				app1.setDrSpeciality(rs.getString("DrSpeciality"));
				app1.setAppointmentDate(rs.getString("AppointmentDate"));
				app1.setAppointmentTime(rs.getString("AppointmentTime"));
				app.add(app1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return app;
	}
	
	public Appointmentbean showappointmentbyid(int id) {
		Appointmentbean app1 = new Appointmentbean();

		try {
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

			String sql = "select * from appointment INNER JOIN user_regi on appointment.u_id=user_regi.u_id where appointment.id="+id;

			PreparedStatement pst = cnn.prepareStatement(sql);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				
				app1.setId(rs.getInt("id"));
				app1.setDrName(rs.getString("DrName"));
				app1.setDrSpeciality(rs.getString("DrSpeciality"));
				app1.setAppointmentDate(rs.getString("AppointmentDate"));
				app1.setAppointmentTime(rs.getString("AppointmentTime"));
				app1.setFname(rs.getString("u_fname"));
				app1.setLname(rs.getString("u_lname"));
				app1.setUid(rs.getInt("u_id"));
//				app1.add(app1);
				return app1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return app1;
	}

	public void admindelappt(int id) {
		try {
			DBconnection db = new DBconnection();
			Connection cnn = db.getconnection();

			String sql = "delete from appointment where id=?";

			PreparedStatement pst = cnn.prepareStatement(sql);
			pst.setInt(1, id);
			int i = pst.executeUpdate();

			if (i > 0) {
				System.out.println("Admin Side Appt Deleted");
			} else {
				System.out.println("Admin Side Appt Not Deleted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
